<?php
/*
 * SumOffice for SuiteCRM — ?entryPoint=sumofficeOpen&record={revisionId}
 * Opens the Document revision in SumOffice for the signed-in person.
 */
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}
require_once 'custom/modules/SumOffice/SumOfficeWopi.php';
require_once 'modules/SumOffice/SumOfficeLicenseGate.php';

global $current_user;

// SuiteCRM Store licence check: the store requires isValid() at a critical code point,
// and opening a document for editing is exactly that point (see SumOfficeLicenseGate).
$licence = SumOfficeLicenseGate::check();
if ($licence !== true) {
    $e = function ($s) { return htmlspecialchars((string) $s, ENT_QUOTES); };
    http_response_code(403);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html><head><meta charset="utf-8"><title>SumOffice licence</title></head>'
        . '<body style="font-family:sans-serif;max-width:40em;margin:3em auto;line-height:1.5">'
        . '<h1 style="font-size:1.3em">SumOffice cannot open this document</h1>'
        . '<p>' . $e($licence) . '</p>'
        . (is_admin($current_user)
            ? '<p><a href="index.php?module=SumOffice&amp;action=license">Enter or check the licence key</a></p>'
            : '<p>Please ask your SuiteCRM administrator to check the SumOffice licence key (Admin &gt; SumOffice licence).</p>')
        . '<p><a href="https://store.suitecrm.com/addons/sumoffice" target="_blank" rel="noopener">SumOffice in the SuiteCRM Store</a></p>'
        . '</body></html>';
    sugar_cleanup(true);
    return;
}

$revisionId = preg_replace('/[^A-Za-z0-9-]/', '', (string) ($_GET['record'] ?? ''));
$loaded = $revisionId !== '' ? SumOfficeWopi::load($revisionId) : null;
if (!$loaded) {
    http_response_code(404);
    die('No such document.');
}
[$revision, $document] = $loaded;
if (!SumOfficeWopi::canRead($document)) {
    http_response_code(403);
    die('No access.');
}
$ext = strtolower(pathinfo((string) $revision->filename, PATHINFO_EXTENSION));
if (!in_array($ext, SumOfficeWopi::EXTENSIONS, true)) {
    http_response_code(415);
    die("SumOffice does not open .$ext files.");
}
$discovery = SumOfficeWopi::discovery();
if (!$discovery) {
    http_response_code(503);
    die('SumOffice is not configured: set sumoffice_discovery_url in config_override.php.');
}
$canWrite = SumOfficeWopi::canWrite($document);
$action = $discovery['actions']["$ext|" . ($canWrite ? 'edit' : 'view')] ?? $discovery['actions']["$ext|edit"] ?? null;
if (!$action) {
    http_response_code(503);
    die("SumOffice discovery has no action for .$ext.");
}
$wopiSrc = SumOfficeWopi::siteUrl() . '/custom/modules/SumOffice/wopi.php/' . $revision->id;
$sep = (substr($action, -1) === '?' || substr($action, -1) === '&') ? '' : (strpos($action, '?') !== false ? '&' : '?');
$target = $action . $sep . 'WOPISrc=' . rawurlencode($wopiSrc);
[$token, $expires] = SumOfficeWopi::makeToken((string) $current_user->id, (string) $revision->id, $canWrite);
$h = function ($s) { return htmlspecialchars((string) $s, ENT_QUOTES); };
header('Content-Type: text/html; charset=utf-8');
echo '<!doctype html><html><head><meta charset="utf-8"><title>' . $h($revision->filename) . '</title>'
    . '<style>html,body{margin:0;height:100%;overflow:hidden}iframe{border:0;width:100%;height:100%;display:block}</style></head><body>'
    . '<form id="sumoffice" action="' . $h($target) . '" method="post" target="sumoffice_frame">'
    . '<input type="hidden" name="access_token" value="' . $h($token) . '">'
    . '<input type="hidden" name="access_token_ttl" value="' . ($expires * 1000) . '"></form>'
    . '<iframe name="sumoffice_frame" title="SumOffice" allow="clipboard-read; clipboard-write; fullscreen"></iframe>'
    . '<script>document.getElementById("sumoffice").submit();</script></body></html>';
sugar_cleanup(true);
