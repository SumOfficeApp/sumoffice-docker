<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$license_strings = array (
    'LBL_STEPS_TO_LOCATE_KEY_TITLE' => 'Zum Suchen Sie Ihr Schlüssel',
    'LBL_STEPS_TO_LOCATE_KEY' => '1. Melden Sie sich bei <a href="https://store.suitecrm.com" target="_blank">SuiteCRM Store</a><br/>2. gehen Sie zu Account->Purchases</br>3. Suchen Sie den Schlüssel für den Kauf dieses Add-on<br/>4. Fügen Sie in das Feld Lizenzschlüssel unter<br/>5. Klicken Sie auf "Validate"',
    'LBL_LICENSE_KEY' => 'Lizenzschlüssel',
    'LBL_CURRENT_USERS' => 'Aktuelle Benutzeranzahl',
    'LBL_LICENSED_USERS' => 'Lizenzierte Benutzer Anzahl',
    'LBL_VALIDATE_LABEL' => 'bestätigen',
    'LBL_VALIDATED_LABEL' => 'Validierte',
    'LBL_UNLICENSED_USER_LIST' => 'Unlicensed Users',
    'LBL_LICENSED_USER_LIST' => 'Licensed Users',
    'LBL_AVAILABLE_USERS' => 'Available Licenses',
    'LBL_HOW_MANY_USERS' => 'Additional Licenses Needed',
    'LBL_ADD_USERS_BUTTON_LABEL' => 'Add More Users Now',
    'LBL_HOWTO_REDUCE_LICENSE' => 'Need to decrease your total licenses? Simply log into the SuiteCRM Store and change the number of users for this add-on under your Purchases.',
    'LBL_VALIDATION_REQUIRED' => 'The above License Key validation is required before making changes to your licensed users',
    'LBL_MANAGE_USERS_TITLE' => 'Manage Users',
    'LBL_ERROR_TOO_MANY_USERS' => 'Please add more additional licenses above and try again.',
);

